using Newtonsoft.Json.Linq;
using Microsoft.Maui.Devices.Sensors;

namespace Aviation;

public partial class LocationPage : ContentPage
{
    private LocationService _locationService;
    private HttpClient _client;
    private const string ApiKey = "669327fa47902f38f3b31068f8c8f520";

    public LocationPage()
    {
        InitializeComponent();
        _locationService = new LocationService();
        _client = new HttpClient();
        InitializeCurrentLocationAsync();
    }

    private async Task InitializeCurrentLocationAsync()
    {
        loadingIndicator.IsRunning = true;
        loadingIndicator.IsVisible = true;
        try
        {
            // Fetch and display current location
            var location = await _locationService.GetCurrentLocation();
            currentLocationLabel.Text = $"Current Location: {location.Latitude:F4}, {location.Longitude:F4}";
        }
        catch (Exception ex)
        {
            currentLocationLabel.Text = $"Error fetching location: {ex.Message}";
        }
        finally
        {
            loadingIndicator.IsRunning = false;
            loadingIndicator.IsVisible = false;
        }
    }

    private async void OnLocationSearchPressed(object sender, EventArgs e)
    {
        loadingIndicator.IsRunning = true;
        loadingIndicator.IsVisible = true;

        string searchQuery = locationSearchBar.Text;
        if (string.IsNullOrWhiteSpace(searchQuery))
        {
            weatherResultLabel.Text = "Please enter a valid location.";
            return;
        }

        try
        {
            // Use a geocoding service to resolve the query into coordinates
            var (latitude, longitude, errorMessage) = await _locationService.GetLocationByQuery(searchQuery);

            if (!string.IsNullOrEmpty(errorMessage))
            {
                weatherResultLabel.Text = errorMessage;
                return;
            }

            // Fetch weather data for the resolved location
            string weatherData = await FetchWeatherData(latitude.Value, longitude.Value);
            weatherResultLabel.Text = weatherData;
        }
        catch (Exception ex)
        {
            weatherResultLabel.Text = $"Error: {ex.Message}";
        }

        finally
        {
            loadingIndicator.IsRunning = false;
            loadingIndicator.IsVisible = false;
        }
    }

    private async Task<string> FetchWeatherData(double latitude, double longitude)
    {
        try
        {
            string weatherUrl = $"https://api.openweathermap.org/data/2.5/weather?lat={latitude}&lon={longitude}&appid={ApiKey}&units=metric";
            string response = await _client.GetStringAsync(weatherUrl);
            var weatherJson = JObject.Parse(response);

            double temp = weatherJson["main"]["temp"].Value<double>();
            string description = weatherJson["weather"][0]["description"].Value<string>();
            int humidity = weatherJson["main"]["humidity"].Value<int>();
            double windSpeed = weatherJson["wind"]["speed"].Value<double>();

            return $"Weather: {char.ToUpper(description[0]) + description.Substring(1)}\n" +
                   $"Temperature: {temp:F1}�C\n" +
                   $"Humidity: {humidity}%\n" +
                   $"Wind Speed: {windSpeed:F1} m/s";
        }
        catch (Exception ex)
        {
            throw new Exception($"Failed to fetch weather data: {ex.Message}");
        }
    }
}

// Updated LocationService class
public class LocationService
{
    public async Task<(double Latitude, double Longitude)> GetCurrentLocation()
    {
        var status = await Permissions.RequestAsync<Permissions.LocationWhenInUse>();
        if (status != PermissionStatus.Granted)
            throw new Exception("Location permission not granted.");

        var location = await Geolocation.GetLocationAsync(new GeolocationRequest
        {
            DesiredAccuracy = GeolocationAccuracy.Medium,
            Timeout = TimeSpan.FromSeconds(30)
        });

        if (location != null)
            return (location.Latitude, location.Longitude);

        throw new Exception("Unable to fetch current location.");
    }

    public async Task<(double? Latitude, double? Longitude, string ErrorMessage)> GetLocationByQuery(string query)
    {
        const string ApiKey = "AIzaSyDEWKqfkbAlB8nINBZPFg1fu8OUN0zoqHc";
        var baseUrl = "https://maps.googleapis.com/maps/api/geocode/json";

        try
        {
            using var httpClient = new HttpClient();
            var requestUrl = $"{baseUrl}?address={Uri.EscapeDataString(query)}&key={ApiKey}";
            var response = await httpClient.GetStringAsync(requestUrl);

            var jsonResponse = JObject.Parse(response);
            var status = jsonResponse["status"].ToString();

            // Handle various response status codes
            if (status == "OK")
            {
                var location = jsonResponse["results"][0]["geometry"]["location"];
                var latitude = location["lat"].Value<double>();
                var longitude = location["lng"].Value<double>();
                return (latitude, longitude, string.Empty);  // No error
            }
            else if (status == "ZERO_RESULTS")
            {
                return (null, null, "No results found for the given location.");
            }
            else if (status == "REQUEST_DENIED")
            {
                return (null, null, "Request denied. Check your API key and permissions.");
            }
            else if (status == "OVER_QUERY_LIMIT")
            {
                return (null, null, "Query limit exceeded. Try again later.");
            }
            else if (status == "INVALID_REQUEST")
            {
                return (null, null, "Invalid request. Ensure the query is correctly formatted.");
            }
            else
            {
                return (null, null, $"Unexpected error: {status}");
            }
        }
        catch (HttpRequestException ex)
        {
            throw new Exception($"Network error while fetching geocoded data: {ex.Message}");
        }
        catch (Exception ex)
        {
            throw new Exception($"Error while fetching geocoded data: {ex.Message}");
        }
    }

}
