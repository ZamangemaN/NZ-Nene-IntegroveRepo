﻿namespace Aviation;

public partial class MainPage : ContentPage
{
    public MainPage()
    {
        InitializeComponent();
    }

    private async Task AnimateButton(View button)
    {
        // Scale up
        await button.ScaleTo(1.1, 100);
        // Scale back
        await button.ScaleTo(1, 100);
    }

    private async void OnGetStartedClicked(object sender, EventArgs e)
    {
        await AnimateButton((Button)sender);  // Apply animation
        await Navigation.PushAsync(new LoginPage());
    }
}