using Newtonsoft.Json.Linq;

namespace Aviation;

public partial class WeatherPage : ContentPage
{
     // Reusable animation method for hover/touch effect
    private async Task AnimateButton(View button)
    {
        // Scale up
        await button.ScaleTo(1.1, 100);
        // Scale back
        await button.ScaleTo(1, 100);
    }

    public WeatherPage()
    {
        InitializeComponent();
        _client = new HttpClient();
        _geolocation = Geolocation.Default;
        InitializeLocationAndWeatherAsync();
    }

    private const string ApiKey = "669327fa47902f38f3b31068f8c8f520";
    private readonly HttpClient _client;
    private readonly IGeolocation _geolocation;
    private double _latitude;
    private double _longitude;

    private readonly Dictionary<int, (string Condition, string Advisory, bool IsWarning)> _weatherCodes = new()
        {
            { 200, ("TSRA", "WARNING: Thunderstorm with rain. Check CB activity and convective SIGMETS.", true) },
            { 201, ("TSRA", "WARNING: Heavy thunderstorm. IFR conditions likely.", true) },
            { 300, ("DZ", "Light drizzle conditions. Exercise normal caution.", false) },
            { 500, ("RA", "Light rain conditions. Check visibility requirements.", false) },
            { 502, ("+RA", "WARNING: Heavy rain. IFR conditions possible.", true) },
            { 600, ("SN", "WARNING: Snow conditions. Check for airframe icing.", true) },
            { 701, ("BR", "Mist conditions. Monitor visibility.", false) },
            { 741, ("FG", "WARNING: Fog conditions. IFR procedures may be required.", true) },
            { 800, ("SKC", "Sky clear. VFR conditions.", false) },
            { 801, ("FEW", "Few clouds. Good VFR conditions.", false) },
            { 802, ("SCT", "Scattered clouds.", false) },
            { 803, ("BKN", "Broken clouds.", false) },
            { 804, ("OVC", "Overcast conditions.", false) }
        };

    private async Task InitializeLocationAndWeatherAsync()
    {
        LoadingIndicator.IsVisible = true;
        LoadingIndicator.IsRunning = true;

        try
        {
            var status = await CheckAndRequestLocationPermission();
            if (status != PermissionStatus.Granted)
            {
                await DisplayAlert("Permission Required",
                    "Location permission is required for this app to work properly.", "OK");
                return;
            }

            await UpdateLocationAsync();
            await LoadWeatherDataAsync();
        }
        catch (Exception ex)
        {
            await DisplayAlert("Error",
                $"Failed to initialize location services: {ex.Message}", "OK");
        }
        finally
        {
            LoadingIndicator.IsVisible = false;
            LoadingIndicator.IsRunning = false;
        }
    }

    private async Task<PermissionStatus> CheckAndRequestLocationPermission()
    {
        var status = await Permissions.CheckStatusAsync<Permissions.LocationWhenInUse>();

        if (status != PermissionStatus.Granted)
        {
            status = await Permissions.RequestAsync<Permissions.LocationWhenInUse>();
        }

        return status;
    }

    private async Task UpdateLocationAsync()
    {
        try
        {
            var location = await _geolocation.GetLocationAsync(new GeolocationRequest
            {
                DesiredAccuracy = GeolocationAccuracy.Medium,
                Timeout = TimeSpan.FromSeconds(5)
            });

            if (location != null)
            {
                _latitude = location.Latitude;
                _longitude = location.Longitude;
            }
            else
            {
                throw new Exception("Unable to get location.");
            }
        }
        catch (Exception ex)
        {
            await DisplayAlert("Location Error",
                $"Failed to get current location: {ex.Message}", "OK");
            throw;
        }
    }

    protected override async void OnAppearing()
    {
        base.OnAppearing();
        await InitializeLocationAndWeatherAsync();
    }

    private async void OnRefreshWeatherClicked(object sender, EventArgs e)
    {
        
        await InitializeLocationAndWeatherAsync();
    }

    private string GenerateMetarLikeString(JObject weather)
    {
        var temp = weather["main"]["temp"].Value<double>();
        var windSpeed = weather["wind"]["speed"].Value<double>();
        var windDeg = weather["wind"].Value<JObject>().ContainsKey("deg") ?
                     weather["wind"]["deg"].Value<int>() : 0;
        var weatherId = weather["weather"][0]["id"].Value<int>();
        var visibility = weather["visibility"].Value<int>();
        var pressure = weather["main"]["pressure"].Value<int>();

        var windKnots = Math.Round(windSpeed * 1.944);

        string weatherCode = "CLR";
        if (_weatherCodes.ContainsKey(weatherId))
        {
            weatherCode = _weatherCodes[weatherId].Condition;
        }

        return $"METAR FAWK {DateTime.UtcNow:ddHHmm}Z " +
               $"{windDeg:000}{windKnots:00}KT " +
               $"{visibility / 1000:000}KM " +
               $"{weatherCode} " +
               $"{Math.Round(temp):00}/{Math.Round(GetDewPoint(temp, 70)):00} " +
               $"Q{pressure:0000}";
    }

    private double GetDewPoint(double temp, double humidity)
    {
        double a = 17.27;
        double b = 237.7;
        double alpha = a * temp / (b + temp) + Math.Log(humidity / 100.0);
        return b * alpha / (a - alpha);
    }

    private async Task LoadWeatherDataAsync()
    {
        try
        {
            LoadingIndicator.IsVisible = true;
            LoadingIndicator.IsRunning = true;

            string currentUrl = $"https://api.openweathermap.org/data/2.5/weather?lat={_latitude}&lon={_longitude}&appid={ApiKey}&units=metric";
            string forecastUrl = $"https://api.openweathermap.org/data/2.5/forecast?lat={_latitude}&lon={_longitude}&appid={ApiKey}&units=metric";

            string currentResponse = await _client.GetStringAsync(currentUrl);
            var currentWeather = JObject.Parse(currentResponse);

            string forecastResponse = await _client.GetStringAsync(forecastUrl);
            var forecast = JObject.Parse(forecastResponse);

            await MainThread.InvokeOnMainThreadAsync(async () =>
            {
                var temp = currentWeather["main"]["temp"].Value<double>();
                var windSpeed = currentWeather["wind"]["speed"].Value<double>();
                var description = currentWeather["weather"][0]["description"].Value<string>();
                var weatherId = currentWeather["weather"][0]["id"].Value<int>();
                var pressure = currentWeather["main"]["pressure"].Value<int>();
                var visibility = currentWeather["visibility"].Value<int>();

                MetarLabel.Text = GenerateMetarLikeString(currentWeather);

                TemperatureLabel.Text = $"Temperature: {temp:F1}�C";
                WindLabel.Text = $"Wind: {windSpeed:F1} m/s";
                CloudCoverLabel.Text = $"Weather: {char.ToUpper(description[0]) + description.Substring(1)}";
                PressureLabel.Text = $"QNH: {pressure} hPa";
                VisibilityLabel.Text = $"Visibility: {visibility / 1000} km";

                LocationStatusLabel.Text = $"Location: {_latitude:F4}, {_longitude:F4}";
                LastUpdateLabel.Text = $"Last updated: {DateTime.Now:HH:mm:ss}";

                if (_weatherCodes.ContainsKey(weatherId))
                {
                    var (_, advisory, isWarning) = _weatherCodes[weatherId];
                    if (!string.IsNullOrEmpty(advisory))
                    {
                        await DisplayAlert(
                            isWarning ? "Weather Warning" : "Weather Advisory",
                            advisory,
                            "Acknowledged");
                    }
                }

                UpdateForecast(forecast);
            });
        }
        catch (HttpRequestException ex)
        {
            await MainThread.InvokeOnMainThreadAsync(async () =>
            {
                if (ex.Message.Contains("401"))
                {
                    await DisplayAlert("API Key Error",
                        "Please check your API key. If you just created it, please wait a few hours for it to activate.", "OK");
                }
                else
                {
                    await DisplayAlert("Network Error",
                        "Unable to connect to weather service. Please check your internet connection.", "OK");
                }
            });
        }
        catch (Exception ex)
        {
            await MainThread.InvokeOnMainThreadAsync(async () =>
            {
                await DisplayAlert("Error", $"Unable to load weather data: {ex.Message}", "OK");
            });
        }
        finally
        {
            LoadingIndicator.IsVisible = false;
            LoadingIndicator.IsRunning = false;
        }
    }

    private void UpdateForecast(JObject forecast)
    {
        var forecastList = forecast["list"].ToArray();

        var tomorrowForecast = forecastList
            .FirstOrDefault(x => DateTime.Parse(x["dt_txt"].ToString())
                .Date == DateTime.Now.AddDays(1).Date);

        if (tomorrowForecast != null)
        {
            var tomorrowTemp = tomorrowForecast["main"]["temp"].Value<double>();
            var tomorrowDesc = tomorrowForecast["weather"][0]["description"].Value<string>();
            TomorrowTemp.Text = $"Temp: {tomorrowTemp:F1}�C";
            TomorrowCondition.Text = $"Condition: {char.ToUpper(tomorrowDesc[0]) + tomorrowDesc.Substring(1)}";
        }

        var dayAfterForecast = forecastList
            .FirstOrDefault(x => DateTime.Parse(x["dt_txt"].ToString())
                .Date == DateTime.Now.AddDays(2).Date);

        if (dayAfterForecast != null)
        {
            var dayAfterTemp = dayAfterForecast["main"]["temp"].Value<double>();
            var dayAfterDesc = dayAfterForecast["weather"][0]["description"].Value<string>();
            DayAfterTemp.Text = $"Temp: {dayAfterTemp:F1}�C";
            DayAfterCondition.Text = $"Condition: {char.ToUpper(dayAfterDesc[0]) + dayAfterDesc.Substring(1)}";
        }
    }
}
