﻿using Firebase.Database;
using Firebase.Database.Query;
using FirebaseAdmin;
using Google.Apis.Auth.OAuth2;
using Microsoft.Maui.ApplicationModel;
using Microsoft.Maui.Controls;

namespace Aviation
{
    public partial class App : Application
    {
        public static FirebaseClient FirebaseClient { get; private set; }

        public App()
        {
            InitializeComponent();
            
            InitializeFirebase();
            MainPage = new NavigationPage(new MainPage());
        }

        private void InitializeFirebase()
        {
            try
            {
                if (FirebaseApp.DefaultInstance == null)
                {
                    FirebaseApp.Create(new AppOptions
                    {
                        Credential = GoogleCredential.FromFile("Aviation\\projectavigo-firebase-adminsdk-ycvog-70c93992ff.json")
                    });
                }

                // Initialize Firebase Realtime Database client
                FirebaseClient = new FirebaseClient("https://projectavigo-default-rtdb.firebaseio.com/");
                Console.WriteLine("Firebase Realtime Database initialized successfully.");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error initializing Firebase: {ex.Message}");
            }
        }
    }
}
