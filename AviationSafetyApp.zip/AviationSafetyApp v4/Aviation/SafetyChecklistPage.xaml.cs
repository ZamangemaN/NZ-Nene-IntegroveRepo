using Firebase.Auth;
using Microsoft.Maui.Controls;
using Firebase.Database;
using Firebase.Database.Query;

namespace Aviation
{
    public partial class SafetyChecklistPage : ContentPage
    {
        // Firebase client for interacting with Firebase Realtime Database
        private readonly FirebaseClient firebaseClient = new FirebaseClient("https://projectavigo-default-rtdb.firebaseio.com");

        // Constructor for SafetyChecklistPage
        public SafetyChecklistPage()
        {
            // Initialize the page components
            InitializeComponent();
        }

        // This method is called when the "Submit Details" button is clicked
        private async void OnSubmitDetailsClicked(object sender, EventArgs e)
        {

            SubmitDetailsButton.IsEnabled = false;

            loadingIndicator.IsRunning = true;
            loadingIndicator.IsVisible = true;



            // Validate that all required fields are filled out
            if (string.IsNullOrWhiteSpace(AircraftRegistration.Text) ||
                string.IsNullOrWhiteSpace(AircraftType.Text) ||
                string.IsNullOrWhiteSpace(AircraftModel.Text))
            {
                // If any required field is empty, show an error message
                await DisplayAlert("Validation Error", "Please fill in all required fields.", "OK");
                return;
            }

            // Update the summary labels with the values from the input fields
            AircraftRegSummary.Text = $"Registration: {AircraftRegistration.Text}";
            AircraftTypeSummary.Text = $"Type: {AircraftType.Text}";
            AircraftModelSummary.Text = $"Model: {AircraftModel.Text}";

            // Hide the input forms and show the summary and checklist sections
            InputFormsSection.IsVisible = false;
            DetailsSummarySection.IsVisible = true;
            SafetyChecklistSection.IsVisible = true;

            // Save the aircraft details
            await SaveAircraftDetails();

            // Display a success message
            await DisplayAlert("Success", "Details submitted successfully. Please proceed with the safety checklist.", "OK");

            loadingIndicator.IsRunning = false;
            loadingIndicator.IsVisible = false;
        }

        // Save aircraft details to Firebase Realtime Database
        private async Task SaveAircraftDetails()
        {
            loadingIndicator.IsRunning = true;
            loadingIndicator.IsVisible = true;

            try
            {
                string aircraftId = AircraftRegistration.Text;

                var aircraft = new
                {
                    AircraftID = aircraftId,
                    Model = AircraftModel.Text,
                    RegNumber = AircraftRegistration.Text
                };

                // Use the SaveToFirebase method for saving data
                await SaveToFirebase("Aircraft", aircraftId, aircraft);

                // Display a success message
                await DisplayAlert("Success", "Aircraft details saved successfully.", "OK");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error saving aircraft details: {ex.Message}");
                await DisplayAlert("Error", "Failed to save aircraft details. Please try again.", "OK");
            }
            finally
            { loadingIndicator.IsRunning = false; }
            { loadingIndicator.IsVisible = false ; }
        }

        // General method to save data to Firebase
        private async Task SaveToFirebase<T>(string path, string id, T data)
        {
            loadingIndicator.IsVisible = true;
            loadingIndicator.IsRunning = true;

            try
            {
                await firebaseClient.Child(path)
                    .Child("Authentication")
                    .Child(id)
                    .PutAsync(data);
                Console.WriteLine("Data saved successfully.");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error saving data: {ex.Message}");
                await DisplayAlert("Error", "Failed to save data. Please try again.", "OK");
            }
           finally
           { loadingIndicator.IsVisible = false ;
                loadingIndicator.IsRunning = false;

            }
        }

        // This method is called when the "Confirm Checklist" button is clicked
        private async void OnConfirmChecklistClicked(object sender, EventArgs e)
        {
            loadingIndicator.IsRunning = true;
            loadingIndicator.IsVisible = true;
            var uncheckedItems = new List<string>();

            if (!CheckAircraft.IsChecked)
                uncheckedItems.Add("Aircraft documentation and airworthiness");
            if (!CheckWeather.IsChecked)
                uncheckedItems.Add("Weather conditions and forecast");
            if (!CheckFuel.IsChecked)
                uncheckedItems.Add("Fuel and oil levels");
            if (!CheckWeight.IsChecked)
                uncheckedItems.Add("Weight and balance calculations");

            if (uncheckedItems.Count > 0)
            {
                string message = "The following items need to be checked:\n\n";
                message += string.Join("\n", uncheckedItems);

                // Check if Shell.Current is not null before calling DisplayAlert
                if (Shell.Current != null)
                {
                    await Shell.Current.DisplayAlert(
                        "Incomplete Checklist",
                        message,
                        "OK"
                    );
                }
                else
                {
                    // If Shell.Current is null, use the DisplayAlertIfPossible method
                    await DisplayAlertIfPossible("Warning", "Please make sure the checklist is complete", "OK");
                }
                loadingIndicator.IsRunning = false;
                loadingIndicator.IsVisible = false;
                return;
            }

            // If all checkboxes are checked, display success alert
            if (Shell.Current != null)
            {
                await Shell.Current.DisplayAlert(
                    "Checklist Completed",
                    "You have successfully completed the pre-flight safety checklist.",
                    "OK"
                );
            }
            else
            {
                await DisplayAlertIfPossible("Checklist completed", "You may prepare for take off.", "OK");
            }



            // Create checklist data to be saved
            var checklistData = new
            {
                AircraftDocumentationChecked = CheckAircraft.IsChecked,
                WeatherChecked = CheckWeather.IsChecked,
                FuelChecked = CheckFuel.IsChecked,
                WeightChecked = CheckWeight.IsChecked
            };

            try
            {
                string aircraftId = AircraftRegistration.Text;

                // Save checklist data using the SaveToFirebase method
                await SaveToFirebase("checklists", aircraftId, checklistData);

                // Display a success message
                await DisplayAlert("Checklist Completed", "You have successfully completed the pre-flight safety checklist.", "OK");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error saving checklist data: {ex.Message}");
                await DisplayAlert("Error", "Failed to save checklist data. Please try again.", "OK");
            }
            finally
            {
                loadingIndicator.IsRunning = false;
                loadingIndicator.IsVisible = false;
                await Navigation.PushAsync(new Emergency());
            }
        }

        // This method is used to display an alert if Shell.Current is null
        private async Task DisplayAlertIfPossible(string title, string message, string buttonText)
        {
            try
            {
                // Use Application.Current.MainPage to display the alert if Shell.Current is null
                await Application.Current.MainPage.DisplayAlert(title, message, buttonText);
            }
            catch (Exception)
            {
                // Handle any exceptions that may occur when trying to display the alert
                Console.WriteLine($"Unable to display alert: {message}");
            }
        }

        // This method is called when a checkbox in the checklist is changed
        private async void OnCheckboxChanged(object sender, CheckedChangedEventArgs e)
        {
            // Count the total number of checked boxes
            int totalChecked = 0;
            if (CheckAircraft.IsChecked) totalChecked++;
            if (CheckWeather.IsChecked) totalChecked++;
            if (CheckFuel.IsChecked) totalChecked++;
            if (CheckWeight.IsChecked) totalChecked++;

            // Calculate the progress (0.25 for each item)
            double progress = totalChecked / 4.0;

            // Update the progress bar
            ChecklistProgress.Progress = progress;

            // Update the progress label
            int percentComplete = (int)(progress * 100);
            ProgressLabel.Text = $"{percentComplete}% Complete";

            // The Confirm button should always be enabled, regardless of the checklist completion status
            SafetyChecklistButton.IsEnabled = true;

            
        }
    }
}
