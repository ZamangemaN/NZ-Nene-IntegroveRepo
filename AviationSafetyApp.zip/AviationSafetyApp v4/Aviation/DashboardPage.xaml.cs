using Firebase.Auth;
using Firebase.Database;
using FirebaseAdmin;
using FirebaseAdmin.Auth;



namespace Aviation;


public partial class DashboardPage : ContentPage
{
     

    public DashboardPage()
    {
        InitializeComponent();
       
    }



    // Reusable animation method for hover/touch effect
    private async Task AnimateButton(View button)
    {
        // Scale up
        await button.ScaleTo(1.1, 100);
        // Scale back
        await button.ScaleTo(1, 100);
    }


    private async void OnViewChecklistClicked(object sender, EventArgs e)
    {
        await AnimateButton((Button)sender);  // Apply animation

        await Navigation.PushAsync(new SafetyChecklistPage());
    }

    private async void OnCheckWeatherClicked(object sender, EventArgs e)
    {
        await AnimateButton((Button)sender);  // Apply animation
        await Navigation.PushAsync(new WeatherPage());
    }

    private async void OnLocationClicked(object sender, EventArgs e)
    {
        await AnimateButton((Button)sender);  // Apply animation
        await Navigation.PushAsync(new LocationPage());
    }

    private async void OnViewProceduresClicked(object sender, EventArgs e)
    {
        await AnimateButton((Button)sender);  // Apply animation
        await Navigation.PushAsync(new Emergency());
    }
}