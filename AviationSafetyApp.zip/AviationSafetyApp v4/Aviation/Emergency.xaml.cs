using Firebase.Database;
using Firebase.Database.Query;

namespace Aviation
{
    public partial class Emergency : ContentPage
    {
        // Firebase client for interacting with Firebase Realtime Database
        private readonly FirebaseClient firebaseClient = new FirebaseClient("https://projectavigo-default-rtdb.firebaseio.com");

        public Emergency()
        {
            InitializeComponent();
        }

        private async Task AnimateButton(View button)
        {
            await button.ScaleTo(1.1, 100);
            await button.ScaleTo(1, 100);
        }

        private async void OnConfirmChecklistClicked(object sender, EventArgs e)
        {
            loadingIndicator.IsRunning = true;
            loadingIndicator.IsVisible = true;

            await AnimateButton((Button)sender);

            // Check if all items are checked
            bool allChecked = Parachuts.IsChecked &&
                              Fire_Extinguisher.IsChecked &&
                              Emergency_door.IsChecked &&
                              BackupLandingGear.IsChecked;

            if (allChecked)
            {
                // Show a success message
                await DisplayAlert("Ready for Takeoff", "All emergency items have been checked. You're cleared for takeoff!", "OK");

                // Save the checklist to Firebase
                await SaveEmergencyChecklist();
                await Navigation.PushAsync(new DashboardPage());
            }
            else
            {
                // Show a warning message if not all items are checked
                await DisplayAlert("Warning", "Please check all emergency items before proceeding.", "OK");
            }
            

            loadingIndicator.IsRunning = false; ;
            loadingIndicator.IsVisible = false;
            
        }


        private async void OnCheckboxChanged(object sender, CheckedChangedEventArgs e)
        {
            // Count the total number of checked boxes
            int totalChecked = 0;
            if (Parachuts.IsChecked) totalChecked++;
            if (Fire_Extinguisher.IsChecked) totalChecked++;
            if (Emergency_door.IsChecked) totalChecked++;
            if (BackupLandingGear.IsChecked) totalChecked++;

            // Calculate the progress (0.25 for each item)
            double Progress = totalChecked / 4.0;

            // Update the progress bar
            ChecklistProgress.Progress = Progress;

            // Update the progress label
            int percentComplete = (int)(Progress * 100);
            ProgressLabel.Text = $"{percentComplete}% Complete";

            // The Confirm button should always be enabled, regardless of the checklist completion status
            EmergencyChecklistButton.IsEnabled = true;
        }

        // Method to save the emergency checklist to Firebase
        private async Task SaveEmergencyChecklist()
        {
            loadingIndicator.IsRunning = true;
            loadingIndicator.IsVisible = true;

            try
            {
                // Checklist data to save
                var checklistData = new
                {
                    ParachutesChecked = Parachuts.IsChecked,
                    FireExtinguisherChecked = Fire_Extinguisher.IsChecked,
                    EmergencyDoorChecked = Emergency_door.IsChecked,
                    BackupLandingGearChecked = BackupLandingGear.IsChecked
                };

                // Save to Firebase under "emergency_checklists"
                await firebaseClient
                    .Child("emergency_checklists")
                    .PostAsync(checklistData);

                Console.WriteLine("Emergency checklist saved successfully.");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error saving emergency checklist: {ex.Message}");
                await DisplayAlert("Error", "Failed to save the emergency checklist. Please try again.", "OK");
            }
            finally
            {
                loadingIndicator.IsRunning = false;
                loadingIndicator.IsVisible = false;

            }
        }


    }
}
